export default interface SignUpRequestDto {
    id: string;
    password: string;
    email: string;
    certificationNumber: string;
}