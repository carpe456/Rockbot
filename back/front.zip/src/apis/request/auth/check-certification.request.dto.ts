export default interface CheckCertificationRequestDto {
    id: string;
    email: string;
    certificationNumber: string;
}