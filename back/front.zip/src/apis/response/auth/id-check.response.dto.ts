import ResponseDto from "../response.dto";

export default interface IdCheckResponseDto extends ResponseDto{

}