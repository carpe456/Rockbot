import ResponseDto from "../response.dto";

export default interface EmailCertificationResponseDto extends ResponseDto {

}