import ResponseDto from "../response.dto";

export default interface CheckCertificationResponsetDto extends ResponseDto {

}